from django.shortcuts import render,HttpResponse
from django.contrib.auth import authenticate, login
from django.contrib.auth.models import User
from django.contrib import auth

# Create your views here.
def signup(request):
    if(request.method=="POST"):
        first_name=request.POST['firstname']
        last_name=request.POST['lastname']
        username=request.POST['username']
        email=request.POST['email']
        password=request.POST['password']
        # phonenumber=request.POST['phonenumber']
        print(first_name,last_name,username,email,password)
        myuser=User.objects.create_user(first_name=first_name,email=email,last_name=last_name,username=username,password=password)
        myuser.save()
        return HttpResponse("User has been created succesfully!!!")
    return render(request,'signup.html')

def login(request):
    if  request.method=="POST":
        username=request.POST['username']
        password=request.POST['password']
        user=auth.authenticate(username=username,password=password)
        superusers = User.objects.get(is_superuser=True)
        if user==superusers:
           auth.login(request,user)
           return render(request,"tempadmin.html") 
        else:

            if user is not None:
                auth.login(request,user)
                return render(request,'tempuser.html')
            else:
                msg='Invalid credentials'
    return render(request,'login.html')
