from django.apps import AppConfig


class GroupprojectConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'groupproject'
